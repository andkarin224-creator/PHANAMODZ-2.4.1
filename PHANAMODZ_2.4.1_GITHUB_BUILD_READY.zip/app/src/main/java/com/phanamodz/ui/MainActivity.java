package com.phanamodz.ui;

import android.app.*;
import android.content.*;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.*;
import android.provider.Settings;
import android.view.*;
import android.widget.*;

public class MainActivity extends Activity {
    LinearLayout root; TextView status, progress; int blue=Color.rgb(36,151,255), green=Color.rgb(41,229,126), red=Color.rgb(255,62,87);
    int dp(float v){return (int)(v*getResources().getDisplayMetrics().density+.5f);}
    TextView tv(String s,float z){TextView t=new TextView(this);t.setText(s);t.setTextColor(Color.WHITE);t.setTextSize(z);return t;}
    GradientDrawable bg(int color,float r){GradientDrawable g=new GradientDrawable();g.setColor(color);g.setCornerRadius(dp(r));return g;}
    Button btn(String s){Button b=new Button(this);b.setText(s);b.setTextColor(Color.WHITE);b.setAllCaps(false);b.setTextSize(15);b.setBackground(bg(Color.rgb(12,25,48),18));return b;}

    @Override public void onCreate(Bundle b){super.onCreate(b); build();}
    void build(){
        ScrollView sc=new ScrollView(this); root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(dp(18),dp(18),dp(18),dp(25));root.setBackgroundResource(com.phanamodz.ui.R.drawable.panel_background);sc.addView(root);
        LinearLayout hero=new LinearLayout(this);hero.setOrientation(LinearLayout.VERTICAL);hero.setGravity(Gravity.CENTER_HORIZONTAL);hero.setPadding(0,dp(12),0,dp(12));
        TextView logo=tv("P",62);logo.setGravity(Gravity.CENTER);logo.setTextColor(Color.WHITE);logo.setBackground(bg(Color.rgb(72,95,255),28));hero.addView(logo,new LinearLayout.LayoutParams(dp(120),dp(120)));
        TextView title=tv("PHANAMODZ",28);title.setTypeface(null,1);title.setTextColor(Color.WHITE);hero.addView(title);
        TextView ver=tv("2.4.1",20);ver.setTextColor(Color.rgb(150,190,255));hero.addView(ver);
        root.addView(hero);

        status=tv("●  OFF",20);status.setGravity(Gravity.CENTER);status.setTextColor(red);status.setPadding(0,dp(12),0,dp(12));root.addView(status,new LinearLayout.LayoutParams(-1,dp(62)));
        Button activate=btn("🔑  ใส่คีย์ / เปิดใช้งาน");root.addView(activate,new LinearLayout.LayoutParams(-1,dp(58)));
        activate.setOnClickListener(v->{status.setText("●  ON");status.setTextColor(green);});

        progress=tv("0 / 10",14);progress.setGravity(Gravity.CENTER);progress.setTextColor(Color.LTGRAY);
        Button pull=btn("⇩  แตะปุ่มเพื่อดึงค่าฟังก์ชัน");root.addView(pull,new LinearLayout.LayoutParams(-1,dp(58)));root.addView(progress,new LinearLayout.LayoutParams(-1,dp(36)));
        pull.setOnClickListener(v->{new Thread(()->{for(int i=0;i<=10;i++){int n=i;try{Thread.sleep(160);}catch(Exception e){}runOnUiThread(()->progress.setText(n==10?"10 / 10  ✓":n+" / 10"));}}).start();});

        Button open=btn("▦  แตะเพื่อเปิดเมนูฟังก์ชัน");root.addView(open,new LinearLayout.LayoutParams(-1,dp(58)));
        open.setOnClickListener(v->{
            if(!Settings.canDrawOverlays(this)){startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:"+getPackageName())));return;}
            startService(new Intent(this,PanelService.class));
        });
        TextView note=tv("\nUI VERSION • 2.4.1\nFloating panel • draggable • close with X",12);note.setTextColor(Color.rgb(95,116,150));root.addView(note);
        setContentView(sc);
    }
}