package com.phanamodz.ui;

import android.app.*;
import android.content.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.net.Uri;
import android.os.*;
import android.view.*;
import android.widget.*;

public class PanelService extends Service {
 WindowManager wm; View panel; int blue=Color.rgb(36,151,255), cyan=Color.rgb(24,216,255), red=Color.rgb(255,62,87);
 int dp(float v){return (int)(v*getResources().getDisplayMetrics().density+.5f);}
 GradientDrawable bg(int c,float r){GradientDrawable g=new GradientDrawable();g.setColor(c);g.setCornerRadius(dp(r));g.setStroke(dp(1),Color.rgb(39,64,100));return g;}
 TextView tv(String s,float z){TextView t=new TextView(this);t.setText(s);t.setTextColor(Color.WHITE);t.setTextSize(z);t.setPadding(dp(10),dp(8),dp(10),dp(8));return t;}
 Button b(String s){Button x=new Button(this);x.setText(s);x.setTextColor(Color.WHITE);x.setAllCaps(false);x.setTextSize(14);x.setBackground(bg(Color.rgb(7,18,34),16));return x;}

 @Override public void onCreate(){super.onCreate();startForeground(241,notification());show();}
 Notification notification(){String id="phana";NotificationChannel c=new NotificationChannel(id,"PHANAMODZ Panel",NotificationManager.IMPORTANCE_LOW);((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(c);return new Notification.Builder(this,id).setContentTitle("PHANAMODZ 2.4.1").setContentText("Floating UI active").setSmallIcon(android.R.drawable.ic_dialog_info).build();}

 void show(){
  LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(dp(10),dp(8),dp(10),dp(10));box.setBackgroundResource(com.phanamodz.ui.R.drawable.panel_background);
  LinearLayout head=new LinearLayout(this);head.setGravity(Gravity.CENTER_VERTICAL);
  TextView title=tv("PHANAMODZ 2.4.1",20);title.setTextColor(Color.rgb(140,185,255));title.setTypeface(null,1);head.addView(title,new LinearLayout.LayoutParams(0,dp(52),1));
  Button close=b("✕");close.setTextColor(red);head.addView(close,new LinearLayout.LayoutParams(dp(55),dp(48)));close.setOnClickListener(v->stopSelf());box.addView(head);

  LinearLayout tabs=new LinearLayout(this);tabs.setPadding(0,dp(4),0,dp(8));
  LinearLayout body=new LinearLayout(this);body.setOrientation(LinearLayout.VERTICAL);
  Button a=b("AimBot"),t=b("Target"),s=b("Settings");tabs.addView(a,new LinearLayout.LayoutParams(0,dp(48),1));tabs.addView(t,new LinearLayout.LayoutParams(0,dp(48),1));tabs.addView(s,new LinearLayout.LayoutParams(0,dp(48),1));box.addView(tabs);box.addView(body,new LinearLayout.LayoutParams(-1,dp(310)));
  Runnable aim=()->{body.removeAllViews(); row(body,"◎  Strong suction target");row(body,"☝  Sensitivity of touch");row(body,"▣  Reduce the vibration of the gun");};
  Runnable target=()->{body.removeAllViews();row(body,"◎  เป้ากลางจอ");row(body,"●  เลือกสีของเป้า");SeekBar size=new SeekBar(this);TextView z=tv("ขนาดของเป้า",14);body.addView(z);body.addView(size);};
  Runnable settings=()->{body.removeAllViews();row(body,"◈  ปิดกั้นการรบกวนจากภายนอก");TextView sh=tv("♙  Shizuku  ✓",15);sh.setTextColor(Color.rgb(41,229,126));body.addView(sh);TextView link=tv("🔗  ติดต่อเจ้าของค่าย KH STORE",14);link.setTextColor(Color.rgb(120,180,255));link.setOnClickListener(v->{Intent i=new Intent(Intent.ACTION_VIEW, Uri.parse("https://khewinstore.pages.dev/?utm_source=ig&utm_medium=social&utm_content=link_in_bio"));i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);startActivity(i);});body.addView(link);};
  a.setOnClickListener(v->aim.run());t.setOnClickListener(v->target.run());s.setOnClickListener(v->settings.run());aim.run();

  wm=(WindowManager)getSystemService(WINDOW_SERVICE);WindowManager.LayoutParams lp=new WindowManager.LayoutParams(dp(350),WindowManager.LayoutParams.WRAP_CONTENT,WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,PixelFormat.TRANSLUCENT);lp.gravity=Gravity.TOP|Gravity.START;lp.x=dp(12);lp.y=dp(100);panel=box;wm.addView(box,lp);
  head.setOnTouchListener(new View.OnTouchListener(){float dx,dy;public boolean onTouch(View v,MotionEvent e){if(e.getAction()==0){dx=e.getRawX()-lp.x;dy=e.getRawY()-lp.y;return true;}if(e.getAction()==2){lp.x=(int)(e.getRawX()-dx);lp.y=(int)(e.getRawY()-dy);wm.updateViewLayout(panel,lp);return true;}return false;}});
 }
 void row(LinearLayout body,String label){LinearLayout r=new LinearLayout(this);r.setGravity(Gravity.CENTER_VERTICAL);r.setPadding(0,dp(5),0,dp(5));TextView l=tv(label,14);r.addView(l,new LinearLayout.LayoutParams(0,dp(58),1));Switch sw=new Switch(this);sw.setChecked(false);r.addView(sw,new LinearLayout.LayoutParams(dp(60),dp(58)));body.addView(r);}
 @Override public int onStartCommand(Intent i,int f,int id){return START_STICKY;}
 @Override public void onDestroy(){if(wm!=null&&panel!=null)try{wm.removeView(panel);}catch(Exception e){}super.onDestroy();}
 @Override public IBinder onBind(Intent i){return null;}
}