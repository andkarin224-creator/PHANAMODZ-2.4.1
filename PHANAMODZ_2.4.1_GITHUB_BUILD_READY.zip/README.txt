PHANAMODZ 2.4.1 UI MATCH

ชุดนี้ปรับ UI ให้ใกล้ Mockup ที่สร้างไว้:
- หน้า Home สไตล์ neon blue
- OFF/ON สีแดง/เขียว
- ปุ่มดึงค่า 0-10
- Floating panel หัว PHANAMODZ 2.4.1
- Tabs AimBot / Target / Settings
- Toggle rows
- Target color/size UI
- Shizuku เป็นข้อความสถานะ
- KH STORE link
- ลากพาแนลด้วยแถบหัว
- X เพื่อปิด

ฟังก์ชันทั้งหมดเป็น UI/การตั้งค่าเท่านั้น ไม่ได้แก้เกมหรือทำ aim assist/bypass จริง


BACKGROUND UPDATE:
- ฝังรูปพื้นหลัง neon blue/dark ลงใน drawable/panel_background.png
- หน้าแอปและพาแนลลอยใช้พื้นหลังนี้จริง
- ไม่เปลี่ยนระบบ Toggle / Tabs / Floating Panel อื่น
